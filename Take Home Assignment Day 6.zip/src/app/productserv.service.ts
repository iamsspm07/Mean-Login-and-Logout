import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductservService {
  productId : Subject<any>;
  token:any;
  isAuthenticated:any;
  authStatusListener:any;
  constructor() {
    this.productId = new Subject();
  }

  getFromId(){
    return this.productId.asObservable();
  }
  callById(product: any){
    this.productId.next(product);
  }

  logout(){
    this.token = null;
    this.isAuthenticated = false;
    this.authStatusListener.next(false);  
  }
}
