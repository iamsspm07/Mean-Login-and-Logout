import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { StudentComponent } from './student/student.component';
import { HeaderComponent } from './header/header.component';
import { StudentRegisterComponent } from './student-register/student-register.component';
import { ProductComponent } from './product/product.component';
import { RouterModule } from '@angular/router';
import { GetByProductIdComponent } from './get-by-product-id/get-by-product-id.component';
import { LogoutComponent } from './logout/logout.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    StudentComponent,
    HeaderComponent,
    StudentRegisterComponent,
    ProductComponent,
    GetByProductIdComponent,
    LogoutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
