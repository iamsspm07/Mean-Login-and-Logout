import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthonGuard } from './authon.guard';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { ProductComponent } from './product/product.component';
import { StudentRegisterComponent } from './student-register/student-register.component';
import { StudentComponent } from './student/student.component';

const routes: Routes = [{path:'',component:LoginComponent},
{path:'login',component:LoginComponent},
{path:'register',canActivate:[AuthonGuard],component:StudentRegisterComponent},
{path:'student',canActivate:[AuthonGuard],component:StudentComponent},
{path:'product',canActivate:[AuthonGuard],component:ProductComponent},
{path:'logout',canActivate:[AuthonGuard],component:LogoutComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
